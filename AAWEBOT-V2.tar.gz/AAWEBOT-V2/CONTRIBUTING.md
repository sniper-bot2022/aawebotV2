# How to contribute?

*Welcome on board!*

If U have useful stuff related to this project's Objectives, feel free to create a branch(es) from `main`. Then just add content and [Pull request](https://github.com/codez0mb1e/BinanceBot/pulls) changes. 

Thanks in advance :tada:!