﻿namespace BinanceBot.Market
{

    /// <summary>
    /// MarketStrategy interface
    /// </summary>
    /// <remarks>
    /// As simple as possible now
    /// </remarks>
    public interface IMarketStrategy { }
}